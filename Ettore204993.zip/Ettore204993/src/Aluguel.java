
public class Aluguel {
	
	String nome = "";
	String cpf = "";
	int tempo = 0;
	
	public double Final(){
		double valorfinal;
		
		valorfinal = tempo * 30;
		return valorfinal;
	}
	
}
